-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 22-11-2016 a las 05:39:05
-- Versión del servidor: 5.6.17
-- Versión de PHP: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `bdintencionhoraria`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estudiante`
--

CREATE TABLE IF NOT EXISTS `estudiante` (
  `idCodigo` int(10) NOT NULL,
  `anoPeriodo` varchar(10) NOT NULL,
  `estudiante` varchar(100) NOT NULL,
  `semestre` int(2) NOT NULL,
  `jornada` varchar(20) NOT NULL,
  `sede` varchar(100) NOT NULL,
  `identificacion` int(10) NOT NULL,
  `idPrograma` int(10) NOT NULL,
  `graduado` varchar(2) NOT NULL,
  `email` varchar(100) NOT NULL,
  PRIMARY KEY (`idCodigo`),
  KEY `idPrograma` (`idPrograma`)
) ENGINE=InnoDB DEFAULT CHARSET=ascii;

--
-- Volcado de datos para la tabla `estudiante`
--

INSERT INTO `estudiante` (`idCodigo`, `anoPeriodo`, `estudiante`, `semestre`, `jornada`, `sede`, `identificacion`, `idPrograma`, `graduado`, `email`) VALUES
(1, '2013-1', 'Estudiante Uno', 7, 'Diurna', 'Bogota', 101, 10, 'No', 'estuno@poligran.edu.co'),
(2, '2015-2', 'Estudiante Dos', 2, 'Diurna', 'Bogota', 102, 20, 'No', 'estdos@poligran.edu.co'),
(3, '2016-1', 'Estudiante Tres', 1, 'Nocturna', 'Bogota', 103, 30, 'No', 'esttres@poligran.edu.co'),
(4, '2011-2', 'Estudiante Cuatro', 8, 'Nocturna', 'Bogota', 104, 40, 'Si', 'estcuatro@poligran.edu.co'),
(5, '2014-2', 'Estudiante Cinco', 5, 'Nocturna', 'Bogota', 105, 50, 'No', 'estcinco@poligran.edu.co'),
(6, '2013-1', 'Estudiante Seis', 8, 'Nocturna', 'Bogota', 106, 60, 'No', 'estseis@poligran.edu.co');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `facultad`
--

CREATE TABLE IF NOT EXISTS `facultad` (
  `idFacultad` int(10) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  PRIMARY KEY (`idFacultad`)
) ENGINE=InnoDB DEFAULT CHARSET=ascii;

--
-- Volcado de datos para la tabla `facultad`
--

INSERT INTO `facultad` (`idFacultad`, `nombre`) VALUES
(100, 'Ingenieria y Ciencias Basicas');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `materia`
--

CREATE TABLE IF NOT EXISTS `materia` (
  `codigo` varchar(10) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `prerrequisitos` varchar(100) NOT NULL,
  `pre` tinyint(1) NOT NULL,
  `creditos` int(5) NOT NULL,
  `idPrograma` int(10) NOT NULL,
  KEY `programa` (`idPrograma`),
  KEY `idPrograma` (`idPrograma`)
) ENGINE=InnoDB DEFAULT CHARSET=ascii;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `profesor`
--

CREATE TABLE IF NOT EXISTS `profesor` (
  `codigo` int(20) NOT NULL,
  `nombre` varchar(100) NOT NULL,
  `cedula` int(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `horasSemana` int(5) NOT NULL,
  `idFacultad` int(10) NOT NULL,
  PRIMARY KEY (`codigo`),
  KEY `idFacultad` (`idFacultad`)
) ENGINE=InnoDB DEFAULT CHARSET=ascii;

--
-- Volcado de datos para la tabla `profesor`
--

INSERT INTO `profesor` (`codigo`, `nombre`, `cedula`, `email`, `horasSemana`, `idFacultad`) VALUES
(1, 'Pepito Perez', 12345678, 'pepitoperez@poligran.edu.co', 40, 100),
(2, 'Merengano Lopez', 12345679, 'merenganolopez@poligran.edu.co', 42, 100);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `programa`
--

CREATE TABLE IF NOT EXISTS `programa` (
  `nombre` varchar(50) NOT NULL,
  `duracion` int(5) NOT NULL,
  `idFacultad` int(10) NOT NULL,
  `modalidad` varchar(20) NOT NULL,
  `idPrograma` int(10) NOT NULL,
  PRIMARY KEY (`idPrograma`),
  KEY `idFacultad` (`idFacultad`)
) ENGINE=InnoDB DEFAULT CHARSET=ascii;

--
-- Volcado de datos para la tabla `programa`
--

INSERT INTO `programa` (`nombre`, `duracion`, `idFacultad`, `modalidad`, `idPrograma`) VALUES
('Matematicas', 8, 100, 'Presencial', 10),
('Ingenieria Industrial', 9, 100, 'Presencial', 20),
('Ingenieria en telecomunicaciones', 8, 100, 'Presencial', 30),
('Ingenieria de Sistemas', 8, 100, 'Presencial', 40),
('Ingenieria Industrial Virtual', 10, 100, 'Virtual', 50),
('Ingenieria de Software', 8, 100, 'Virtual', 60);

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `estudiante`
--
ALTER TABLE `estudiante`
  ADD CONSTRAINT `idProgramaEstudiante` FOREIGN KEY (`idPrograma`) REFERENCES `programa` (`idPrograma`);

--
-- Filtros para la tabla `materia`
--
ALTER TABLE `materia`
  ADD CONSTRAINT `idProgramaMateria` FOREIGN KEY (`idPrograma`) REFERENCES `programa` (`idPrograma`);

--
-- Filtros para la tabla `profesor`
--
ALTER TABLE `profesor`
  ADD CONSTRAINT `idFacultadProfesor` FOREIGN KEY (`idFacultad`) REFERENCES `facultad` (`idFacultad`);

--
-- Filtros para la tabla `programa`
--
ALTER TABLE `programa`
  ADD CONSTRAINT `idFacultad` FOREIGN KEY (`idFacultad`) REFERENCES `facultad` (`idFacultad`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
